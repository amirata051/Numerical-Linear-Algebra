import numpy as np

def thomas_solver(A, b):
    L = np.eye(A.shape[0])
    U = np.eye(A.shape[0])

    if np.linalg.det(A) == 0:
        print("Error!! Matrix determinent is zero...")
        
    else:
        # Thomas Algorithm
        U[0][0] = A[0][0]
        for i in range(1, A.shape[0]):
            # Calculating c's
            U[i-1][i] = A[i-1][i]
            # Calculating beta's
            L[i][i-1] = A[i][i-1] / U[i-1][i-1]
            # Calculating alpha's
            U[i][i] = A[i][i] - L[i][i-1] * U[i-1][i]

    # Forward Substitution
    Y = np.zeros((L.shape[1], 1))
    for i in range(L.shape[0]):
        Y[i] = (b[i] - L[i,:].dot(Y)) / L[i][i]

    # Backward Substitution
    X = np.zeros((U.shape[1], 1))
    for i in range(U.shape[0]-1, -1, -1):
        X[i] = (Y[i] - U[i,:].dot(X)) / U[i][i]
        
    return X

def smw_solver(B, c):
    e = np.zeros_like(b)
    e[0] = e[-1] = 1
    A = B - e @ e.T
    u = thomas_solver(A, e)
    v = thomas_solver(A, c)
    x = v - (v[0] + v[-1]) / (u[0] + u[-1] + 1) * u
    return x
    
